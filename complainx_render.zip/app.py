from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
from datetime import date
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = "complaintsystem2024"

# ============================================================
# EMAIL CONFIG — Fill in your Gmail credentials here
# ============================================================
EMAIL_SENDER    = "your_email@gmail.com"      # your Gmail
EMAIL_PASSWORD  = "your_app_password_here"    # Gmail App Password (not your real password)
ADMIN_EMAIL     = "admin_email@gmail.com"     # admin receives new complaint alerts
EMAIL_ENABLED   = False  # Set to True after filling above credentials
# ============================================================

def get_db():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row   # allows dict-style access
    return conn

def init_db():
    conn = get_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            usn      TEXT UNIQUE,
            email    TEXT,
            password TEXT
        )
    ''')
    conn.execute('''
        CREATE TABLE IF NOT EXISTS complaints (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            usn           TEXT,
            email         TEXT,
            message       TEXT,
            category      TEXT,
            location_type TEXT,
            block         TEXT,
            room          TEXT,
            priority      TEXT,
            status        TEXT,
            date          TEXT,
            resolved_date TEXT,
            admin_note    TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# ──────────────────────────────────────────
# EMAIL HELPERS
# ──────────────────────────────────────────
def send_email(to, subject, body_html):
    if not EMAIL_ENABLED:
        return
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = EMAIL_SENDER
        msg["To"]      = to
        msg.attach(MIMEText(body_html, "html"))
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.sendmail(EMAIL_SENDER, to, msg.as_string())
    except Exception as e:
        print(f"[Email Error] {e}")

def notify_student_submitted(email, usn, message, complaint_id):
    send_email(
        to=email,
        subject=f"✅ Complaint #{complaint_id} Submitted",
        body_html=f"""
        <h2 style="color:#6366f1">Complaint Received</h2>
        <p>Hi <b>{usn}</b>,</p>
        <p>Your complaint <b>#{complaint_id}</b> has been submitted successfully.</p>
        <blockquote style="border-left:4px solid #6366f1;padding-left:12px;color:#555">{message}</blockquote>
        <p>We will update you once the status changes.</p>
        """
    )

def notify_admin_new(complaint_id, usn, message, location, priority):
    send_email(
        to=ADMIN_EMAIL,
        subject=f"🔔 New Complaint #{complaint_id} [{priority}]",
        body_html=f"""
        <h2 style="color:#ef4444">New Complaint Alert</h2>
        <table style="border-collapse:collapse;width:100%">
          <tr><td><b>ID</b></td><td>#{complaint_id}</td></tr>
          <tr><td><b>Student</b></td><td>{usn}</td></tr>
          <tr><td><b>Location</b></td><td>{location}</td></tr>
          <tr><td><b>Priority</b></td><td>{priority}</td></tr>
          <tr><td><b>Message</b></td><td>{message}</td></tr>
        </table>
        """
    )

def notify_student_status_change(email, usn, complaint_id, message, new_status, admin_note):
    color = {"Resolved": "#22c55e", "In Progress": "#f59e0b", "Pending": "#ef4444"}.get(new_status, "#6366f1")
    send_email(
        to=email,
        subject=f"📋 Complaint #{complaint_id} Status → {new_status}",
        body_html=f"""
        <h2 style="color:{color}">Status Update: {new_status}</h2>
        <p>Hi <b>{usn}</b>, your complaint has been updated.</p>
        <blockquote style="border-left:4px solid {color};padding-left:12px;color:#555">{message}</blockquote>
        {"<p><b>Admin Note:</b> " + admin_note + "</p>" if admin_note else ""}
        <p style="color:{color}"><b>Current Status: {new_status}</b></p>
        """
    )

# ──────────────────────────────────────────
# REGISTER
# ──────────────────────────────────────────
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        usn      = request.form['usn'].strip().upper()
        email    = request.form['email'].strip()
        password = request.form['password']
        conn = get_db()
        existing = conn.execute("SELECT id FROM users WHERE usn=?", (usn,)).fetchone()
        if existing:
            flash("USN already registered. Please login.", "error")
            conn.close()
            return redirect('/register')
        conn.execute("INSERT INTO users (usn, email, password) VALUES (?,?,?)", (usn, email, password))
        conn.commit()
        conn.close()
        flash("Registered successfully! Please login.", "success")
        return redirect('/')
    return render_template('register.html')

# ──────────────────────────────────────────
# LOGIN
# ──────────────────────────────────────────
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usn      = request.form['usn'].strip().upper()
        password = request.form['password']
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE usn=? AND password=?", (usn, password)).fetchone()
        conn.close()
        if user:
            session['usn']   = user['usn']
            session['email'] = user['email']
            return redirect('/dashboard')
        flash("Invalid USN or password.", "error")
    return render_template('login.html')

# ──────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────
@app.route('/dashboard')
def dashboard():
    if 'usn' not in session:
        return redirect('/')
    conn = get_db()
    complaints = conn.execute(
        "SELECT * FROM complaints WHERE usn=? ORDER BY id DESC",
        (session['usn'],)
    ).fetchall()
    conn.close()
    stats = {
        "total":    len(complaints),
        "pending":  sum(1 for c in complaints if c['status'] == 'Pending'),
        "progress": sum(1 for c in complaints if c['status'] == 'In Progress'),
        "resolved": sum(1 for c in complaints if c['status'] == 'Resolved'),
    }
    return render_template('dashboard.html', complaints=complaints, stats=stats)

# ──────────────────────────────────────────
# SUBMIT
# ──────────────────────────────────────────
@app.route('/submit', methods=['POST'])
def submit():
    if 'usn' not in session:
        return redirect('/')
    conn = get_db()
    cur = conn.execute('''
        INSERT INTO complaints
        (usn, email, message, category, location_type, block, room, priority, status, date, resolved_date, admin_note)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    ''', (
        session['usn'],
        session.get('email', ''),
        request.form['message'],
        request.form['category'],
        request.form['location_type'],
        request.form['block'],
        request.form['room'],
        request.form['priority'],
        "Pending",
        str(date.today()),
        "",
        ""
    ))
    complaint_id = cur.lastrowid
    conn.commit()
    conn.close()

    # Send emails
    location = f"{request.form['location_type']} → {request.form['block']} → {request.form['room']}"
    notify_student_submitted(session.get('email',''), session['usn'], request.form['message'], complaint_id)
    notify_admin_new(complaint_id, session['usn'], request.form['message'], location, request.form['priority'])

    flash("Complaint submitted successfully!", "success")
    return redirect('/dashboard')

# ──────────────────────────────────────────
# ADMIN LOGIN
# ──────────────────────────────────────────
ADMIN_PASSWORD = "admin123"   # Change this!

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form['password'] == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect('/admin')
        flash("Wrong password.", "error")
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect('/admin/login')

# ──────────────────────────────────────────
# ADMIN PANEL
# ──────────────────────────────────────────
@app.route('/admin')
def admin():
    if not session.get('admin'):
        return redirect('/admin/login')

    conn = get_db()
    search   = request.args.get('search', '')
    status_f = request.args.get('status', '')
    cat_f    = request.args.get('category', '')

    query  = "SELECT * FROM complaints WHERE 1=1"
    params = []
    if search:
        query  += " AND (usn LIKE ? OR message LIKE ? OR block LIKE ?)"
        params += [f"%{search}%", f"%{search}%", f"%{search}%"]
    if status_f:
        query  += " AND status=?"
        params.append(status_f)
    if cat_f:
        query  += " AND category=?"
        params.append(cat_f)

    query += " ORDER BY id DESC"
    data   = conn.execute(query, params).fetchall()

    all_data = conn.execute("SELECT * FROM complaints").fetchall()
    stats = {
        "total":    len(all_data),
        "pending":  sum(1 for c in all_data if c['status'] == 'Pending'),
        "progress": sum(1 for c in all_data if c['status'] == 'In Progress'),
        "resolved": sum(1 for c in all_data if c['status'] == 'Resolved'),
    }
    conn.close()
    return render_template('admin.html', data=data, stats=stats,
                           search=search, status_f=status_f, cat_f=cat_f)

# ──────────────────────────────────────────
# UPDATE STATUS
# ──────────────────────────────────────────
@app.route('/update_status/<int:id>', methods=['POST'])
def update_status(id):
    if not session.get('admin'):
        return redirect('/admin/login')

    status     = request.form['status']
    admin_note = request.form.get('admin_note', '')
    resolved_date = str(date.today()) if status == "Resolved" else ""

    conn = get_db()
    complaint = conn.execute("SELECT * FROM complaints WHERE id=?", (id,)).fetchone()
    conn.execute(
        "UPDATE complaints SET status=?, resolved_date=?, admin_note=? WHERE id=?",
        (status, resolved_date, admin_note, id)
    )
    conn.commit()
    conn.close()

    if complaint and complaint['email']:
        notify_student_status_change(
            complaint['email'], complaint['usn'], id,
            complaint['message'], status, admin_note
        )
    return redirect('/admin')

# ──────────────────────────────────────────
# LOGOUT
# ──────────────────────────────────────────
@app.route('/logout')
def logout():
    session.pop('usn', None)
    session.pop('email', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
